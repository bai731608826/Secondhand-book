// 引入 用来发送请求的方法 一定要把路径补全
import { request } from "../../request/request.js" //因为这个 request 请求使用export 导出的 所以要加 双大括号

Page({
  data: {
    src: 'https://img.36krcdn.com/20200409/v2_4eda4b36f70d473494e036d8c996ba3a_img_000'
  },
  imageError: function (e) {
    console.log('image3发生error事件，携带值为', e.detail.errMsg)
  }
})